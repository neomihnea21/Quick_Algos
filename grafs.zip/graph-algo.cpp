#include<iostream>
#include<vector>
#include<queue>
#include<algorithm>
#include<cstring>
using namespace std;
const int MAXN=200000, INF=1e9;
struct edge{
    int x, y, c;
};
bool cmpEdge(edge e1, edge e2){
    return e1.c<e2.c;
}
void dfs(vector<int> g[], int node, int vis[]){ ///vis has to be a bunch of zeroes
    vis[node]=1;
    for(int i=0; i<g[node].size(); i++){
        if(vis[g[node][i]]==0){
            vis[g[node][i]]=1;
            dfs(g, g[node][i], vis);
        }
    }
}
void bfs(vector<int> g[], int i, vector<int> &dist){ //we can modify this to take a vector of starting points
    queue<int>q;
    q.push(i);
    dist[i]=0;
    while(!q.empty()){
        i=q.front();
        q.pop();
        for(int j=0; j<g[i].size(); j++){
            if(dist[g[i][j]]==INF){
                 dist[g[i][j]]=dist[i]+1;
                 q.push(g[i][j]);
            }
        }  
    }
}
void dijkstra(vector<pair<int, int> >g[], int s, vector<int> &dist, vector<int>&dads){
    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > >pq;
    pq.push({0, s}); //The PQ houses <distance, node> pairs
    dist[s]=0;
    dads[s]=0;
    while(!pq.empty()){
        int node=pq.top().second;
        pq.pop();
        for(auto &u: g[node]){
            int neighbor=u.first, weight=u.second;
            if(dist[neighbor]>dist[node]+weight){
                dist[neighbor]=dist[node]+weight;
                dads[neighbor]=node; //this can be deleted
                pq.push({dist[neighbor], neighbor});
            }  
        }

    }
}
//sortare topologica
void dfsTopologic(int src, vector<int> g[], vector<bool> &vis, vector<int> &sortare){
    vis[src]=true;
    for(auto x: g[src]){
        if(!vis[x])
         dfsTopologic(x, g, vis, sortare);
    }
    sortare.push_back(src);
}
void sortaret(int n, vector<int> g[], vector<bool> &vis, vector<int> &sortare){
    vis.assign(n, false);
    sortare.clear();
    for(int i=1; i<=n; i++){
       if(vis[i]==false)
          dfsTopologic(i, g, vis, sortare);
    }
    reverse(sortare.begin(), sortare.end());
}
// chestii legate de APM
int find(vector<int>& sefi, int nod){
    if(nod==sefi[nod]) return nod;
    return sefi[nod]=find(sefi, sefi[nod]);
}
void unify(vector<int>& sefi, int x, int y){
   int sefX=find(sefi, x);
   int sefY=find(sefi, y);
   sefi[sefX]=sefY;
}
int MST(vector<edge> e, int n, vector<edge> &picked){ //graph has n nodes
    sort(e.begin(), e.end(), cmpEdge);
    vector<int> sefi(n+1, 0);
    int ans=0;//we only seek the total cost
    for(int i=1; i<=n; i++){
        sefi[i]=i; 
    }
    for(int i=0; i<e.size(); i++){
        if(find(sefi, e[i].x)!=find(sefi, e[i].y)){
            unify(sefi, e[i].x, e[i].y);//if we want the actual edges in our MST, we ca save them here
            ans+=e[i].c;
            picked.push_back(e[i]);
        }
    }
    return ans;
}


/// chestii specifice la flux
vector<vector<int> >adj, capacity;
// FLUX MAXIM, are nevoie de un BFS mai special decat DFS-ul clasic
int bfs(int s, int t, vector<int>& parent) {
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;
    queue<pair<int, int>> q;
    q.push({s, INF});

    while (!q.empty()) {
        int cur = q.front().first;
        int flow = q.front().second;
        q.pop();

        for (int next : adj[cur]) {
            if (parent[next] == -1 && capacity[cur][next]) {
                parent[next] = cur;
                int new_flow = min(flow, capacity[cur][next]);
                if (next == t)
                    return new_flow;
                q.push({next, new_flow});
            }
        }
    }
    return 0;
}
//Edmonds-Karp in persoana
int fluxMaxim(int s, int t, int n) {
    int flux=0;
    vector<int> tati(n);
    int drumAugmentare;
    while (drumAugmentare!=0) {
        drumAugmentare=bfs(s, t, tati);
        flux+=drumAugmentare;
        int cap=t;
        while (cap!=s) {
            int prev=tati[cap];
            capacity[prev][cap]-=drumAugmentare;
            capacity[cap][prev]+=drumAugmentare;
            cap=prev;
        }
    }
    return flux;
}
vector<int>g[MAXN];
void bfs(vector<pair<int, int> >g[], int i, vector<int> &cost, vector<int>&dads){
    queue<int>q;
    q.push(i);
    dads[i]=0;
    cost[i]=INF;
    while(!q.empty()){
        i=q.front();
        q.pop();
        for(int j=0; j<g[i].size(); j++){
            if(dads[g[i][j].first]==INF){
                 cost[g[i][j].first]=min(cost[i], g[i][j].second);
                 dads[g[i][j].first]=i;
                 q.push(g[i][j].first);
            }
        }  
    }
}
int main(){
    //I am a dreamer, but when I wake
    //you can't break my spirit, it's my dreams you take...
    return 0;
}