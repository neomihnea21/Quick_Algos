#include <iostream>
#include<queue>
#include<cstring>
#define MAXN 1001
#define INF 1e6
using namespace std;
vector<int> g[MAXN];///tinem si capacitatea muchiei
int flow[MAXN][MAXN], cap[MAXN][MAXN];///fluxul preexistent pe fiecare muchie
int vis[MAXN];
int route[MAXN];///tinem ruta ca o lista, refacuta recursiv din BFS, age-old trick
bool bfs(int source, int finish){///functia testeaza si DACA mai exista o cale de a baga flux
    queue<int> q;
    q.push(source);
    memset(vis, 0, sizeof(vis));
    bool isPath=false;
    while(!q.empty()){
        int x=q.front();
        q.pop();
        for(int i=0; i<g[x].size(); i++){
            int next=g[x][i];
            if(flow[x][next]!=cap[x][next]&&vis[next]==0){
                vis[next]=1;
                q.push(next);
                route[next]=x;
                if(next==finish) isPath=true;
            }
        }
    }
    return isPath;///nu punem return in mijlocul functiei
}
int main()
{
    int n, m; cin>>n>>m;//FORMAT INPUT: noduri, arce
    for(int i=0; i<m; i++){//si o lista cu muchiile directe, +capacitatile
        int x, y, c; cin>>x>>y>>c;//asta o bagi cum vine problema, adica pe cuplaj
        cap[x][y]=c;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    int flux=0, minCap;
    bool isRoad=true;
    while(isRoad){
        isRoad=bfs(1, n);
        int nod=n, next;
        minCap=INF;
        while(nod!=1){///ne intoarcem de la destinatie la sursa
            next=route[nod];
            minCap=min(minCap, cap[next][nod]-flow[next][nod]);
            nod=next;
        }
        flux+=minCap;
        nod=n;
        while(nod!=1){
            next=route[nod];
            flow[next][nod]+=minCap;///drumul tur
            flow[nod][next]-=minCap;//si muchia de intoarcere;
            nod=next;
        }
    }
    cout<<flux;
    return 0;
}